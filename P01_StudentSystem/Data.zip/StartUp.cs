﻿using System;

namespace P01_StudentSystem
{
    class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}
